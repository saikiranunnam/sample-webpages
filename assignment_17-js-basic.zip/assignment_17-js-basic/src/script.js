console.log('Dynamically Typed Nature Of JavaScript')

// Declaring a variable
var a
console.log('value of a :', a)
console.log('Datatype of a :', typeof a)

// Assigning a value
a=69
console.log('value of a :', a)
console.log('Datatype of a :', typeof a)

// Assigning a string
a='usk'
console.log('value of a :', a)
console.log('Datatype of a :', typeof a)

// Assigning boolean
a=true
console.log('value of a :', a)
console.log('Datatype of a :', typeof a)

console.log('----------------------------------------------')

console.log('Arithmetic Operations')

var x=100
var y=200

console.log('Addition=',x+y)
console.log('Substraction=',x-y)
console.log('Multiplication=',x*y)
console.log('Exponentiation=',x**y)
console.log('Division=',y/x)
console.log('Modulus=',y%x)
console.log('Increment=',++x)
console.log('Decrement=',--x)
console.log('Increment=',x++)
console.log('Decrement=',x--)

console.log('----------------------------------------------')

console.log('Finding big number in a given 3 numbers')

var q=10
var w=20
var e=1

if(q>w && q>e){
    console.log('Big Number is :',q)
}
else if(w>q && w>e){
    console.log('Big Number is :',w)
}
else{
    console.log('Big Number s :',e)
}

console.log('----------------------------------------------')

console.log('Control statements')

for(var v=1;v<=9;v++){
    console.log("USkc")
}

let i='usk'

while (i < 5) {
    text += "Name is " + i;
    i++;
  }

var l=89
var k=98

var result=l>k ? console.log('l is greater') : console.log('k is greater')