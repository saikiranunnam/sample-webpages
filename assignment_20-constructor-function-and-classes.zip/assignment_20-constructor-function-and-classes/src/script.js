console.log("Student class")

//class syntax for student
class Student{
    //this method is called automatically when a new obj is created
    constructor(rollnumber, name, marks, html, css, js, bs, react) {
        //obj initialization logic
        this.rollnumber = rollnumber;
        this.name = name;
        this.marks = marks;
        this.html = html;
        this.css = css;
        this.js = js;
        this.bs = bs;
        this.react = react;
    }

    getAverageMarks(){
        let total = this.html + this.css + this.js + this.bs + this.react ;
        let avg = total/5;
        return avg;
    }
}

//creation of objects
let std1 = new Student(1,'usk',350,100,100,50,50,50)
let std2 = new Student(2,'aditi',470,100,100,100,100,70)
let std3 = new Student(3,'teju',400,100,100,100,50,50)
let std4 = new Student(4,'jahnavi',390,100,100,70,60,60)
let std5 = new Student(5,'gsr',410,100,100,100,80,30)

//calling function
console.log(std1)
console.log(std1.getAverageMarks())

console.log(std2)
console.log(std2.getAverageMarks())

console.log(std3)
console.log(std3.getAverageMarks())

console.log(std4)
console.log(std4.getAverageMarks())

console.log(std5)
console.log(std5.getAverageMarks())

console.log('------------------------------------------------------')

console.log('Object Literal')

let product = {
    productId:1,
    name:"shoes",
    brand:"Skechers",
    price:5999,
    discount:'10%',

    getDiscount:function(){
        return this.price/100*10;
    }
}

console.log(product)
console.log(product.getDiscount())