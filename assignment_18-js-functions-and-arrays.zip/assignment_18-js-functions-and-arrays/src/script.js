//Sum of elements in an array

console.log("Sum Of Array Elements")
var arr=[10,20,30,1,2,3,4]
sum=0
for(i=0;i<arr.length;i++){
    sum+=arr[i];
}
console.log('sum is:',sum)
console.log('------------------------------------------')

//Displaying even numbers in an array

console.log("Displaying even numbers in an array")
var arr=[10,21,30,1,2,3,32]
for(i of arr){
    if(i%2==0)
        console.log("Even numbers are:",i);
}
console.log('------------------------------------------')

//Displaying min and max values in an array

console.log("Displaying min and max values in an array")
var arr=[10,21,30,1,2,3,31]
var max=arr[0]
var min=arr[0]
for(i of arr){
    if(i>max)
        max=i;
    if(i<min)
        min=i;
}
console.log(`minimum element =${min} maximum element=${max}`);

console.log('------------------------------------------')

//Displaying prime numbers in an array

console.log("Displaying prime numbers in an array")
var arr=[10,5,30,1,2,3,32]
for(i of arr){
    var prime=0;
    for(j=1;j<=i;j++){
        if(i%j==0)
            prime++;
    }
    if(prime==2){
    console.log(i);
    }
}
console.log('------------------------------------------')

//Performing all methods in array

console.log("Performing Insersion,Deletion,Update of Array Elements")
var arr=[10,20,30,1,2,3,4]
//Insertions
console.log('Insertions')
console.log('Initial array:',arr)
//Insertion at beggining
var I1=arr.unshift(100,101)
console.log("Insertion at beginning:",arr)
//Insertion at ending
var I1=arr.push(99,69)
console.log("Insertion at ending:",arr)
//Insertion in between elements
var I1=arr.splice(2,0,143)
console.log("Insertion in Between :",arr)
console.log('------------------------------------------')
//Deletion
console.log('Deletions')
console.log('Initial array:',arr)
//Deletion at beginning
var Re1=arr.shift()
console.log("Deletion from beggining:",arr)
console.log('Removed element is:',Re1)
//Deletion at ending
var Re2=arr.pop()
console.log("Deletion from ending:",arr)
console.log('removed element is :',Re2)
//Deletion in Between
var Re3=arr.splice(1,2)
console.log("Deletion in Between :",arr)
console.log('Removed elements are:',Re3)
console.log('------------------------------------------')
console.log('Replace')
console.log("Initial Array:",arr)
var RE1=arr.splice(2,3,0000)
console.log("Replaced array is:",arr)
console.log("Removed elements are:",RE1)
console.log('------------------------------------------')