//What Is Callback Function

console.log("Callback Function")
function func1(){
    return 'This Is Called Callback Function'
}

function func2(a){
    console.log(a())
}

//calling func2
func2(func1)

console.log('---------------------------------------------------')

//What is Higher Order Function

//here function 3 not fall under higher order function beacuse
//there is no function received as argument or return a function
console.log("Higher Order Function")
function func3(){
    return 'This Is Called Higher Order Function'
}

//here function 4 is a higher order function beacause function 3 
//is given as an argument
function func4(a){
    console.log(a())
}

//calling func4
func2(func3)

console.log('---------------------------------------------------')

console.log("Implementing all operations on an array")
//filter method
console.log('1.using Filter method')
let arr=[69,96,33,66,12,14,22,44,-55]
let data=arr.filter(function(element){
    return element%2==0
})
console.log(data)

//Using arrow function
let arr1=[69,96,33,66,12,14,22,44,-55]
let data1=arr1.filter(element=>element%3==0)
console.log(data1)

console.log('---------------------------------------------------')

//Map method
console.log('2.Using Map method')
let data2=arr.map(function(element){
    return element+10
})
console.log(data2)

//Using arrow function
let data3=arr.map(element=>element-10)
console.log(data3)

console.log('---------------------------------------------------')

console.log("3.using ForEach Method")
arr.forEach(function(element,index){
    console.log(`value at index ${index} is ${element}`)
})

console.log("-------")

//Using arrow function
arr.forEach((element,index)=>{
    console.log(`value at index ${index} is ${element}`)
})

console.log('---------------------------------------------------')

//Reduce method
console.log('4.using Reduce method')
let arr2=[100,-55,10,45]
let sum=arr2.reduce(function(acc,element){
    return acc+element
})

console.log("sum is",sum)

//Using arrow function
let big=arr2.reduce((acc,element)=>acc>element? acc:element)

console.log('big one is',big)

let small=arr2.reduce((acc,element)=>acc<element? acc:element)

console.log('small one is',small)

console.log('---------------------------------------------------')

//Find method
console.log("5.Using Find Method")
let result=arr2.find(function(element){
    return element==10
})
if (result == undefined) {
    console.log("Element Not Found")
}
else {
    console.log("Element Found")
}

//Using arrow function
let result1= arr2.find(element => element == 1)
if (result1 == undefined) {
    console.log("Element not found")
}
else {
    console.log("Element found")
}

console.log('---------------------------------------------------')

//Find index method
console.log("5.Using Find index Method")
let result2=arr2.findIndex(function(element){
    return element==10
})

console.log(result2)

//Using arrow function
let result3= arr2.findIndex(element => element == 45)

console.log(result3)

console.log('---------------------------------------------------')